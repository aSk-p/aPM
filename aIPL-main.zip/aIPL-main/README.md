# aIPL - Termux IP Logger
This tool will log the IP Address, location, current time and User-Agent of a person when they open the link

## How to run aIPL on Termux (Android):

Run these commands:
- `apt update`
- `pkg update`
- `pkg install git`
- `pkg install php`
- `git clone https://github.com/aSk-p/aIPL`
- `cd aIPL`
- `chmod +x *`
- `bash aIPL.sh`

after the victim opens the link you sent, you will get the IP Adress, location, current time and User-Agent of the victim

## How to Update
Check this repository regularly, to check if it got updated.

If it got updated, run the following commands:
- `rm -rf aIPL`
- `git clone https://github.com/aSk-p/aIPL`
- `cd aIPL`
- `bash aIPL.sh`

After that it should work fine!

# Credits
Discord: askxp#0

YouTube: https://youtube.com/@askxp
