#!bin/bash

clear
echo "UPDATING"
sudo apt-get update
clear
echo "INSTALLING PHP"
sudo apt-get install php
clear
echo "INSTALLING CURL"
sudo apt-get install curl
clear
echo "COMPLETED INSTALLATION"
